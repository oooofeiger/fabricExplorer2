import dva from 'dva';
import createLoading from 'dva-loading';

const runtimeDva = window.g_plugins.mergeConfig('dva');
let app = dva({
  history: window.g_history,
  
  ...(runtimeDva.config || {}),
});

window.g_app = app;
app.use(createLoading());
(runtimeDva.plugins || []).forEach(plugin => {
  app.use(plugin);
});

app.model({ namespace: 'global', ...(require('D:/work/pro2.0/src/models/global.js').default) });
app.model({ namespace: 'list', ...(require('D:/work/pro2.0/src/models/list.js').default) });
app.model({ namespace: 'login', ...(require('D:/work/pro2.0/src/models/login.js').default) });
app.model({ namespace: 'menu', ...(require('D:/work/pro2.0/src/models/menu.js').default) });
app.model({ namespace: 'network', ...(require('D:/work/pro2.0/src/models/network.js').default) });
app.model({ namespace: 'project', ...(require('D:/work/pro2.0/src/models/project.js').default) });
app.model({ namespace: 'setting', ...(require('D:/work/pro2.0/src/models/setting.js').default) });
app.model({ namespace: 'user', ...(require('D:/work/pro2.0/src/models/user.js').default) });
app.model({ namespace: 'register', ...(require('D:/work/pro2.0/src/pages/User/models/register.js').default) });
app.model({ namespace: 'CAManager', ...(require('D:/work/pro2.0/src/pages/FabricCA/models/CAManager.js').default) });
app.model({ namespace: 'CAUserManager', ...(require('D:/work/pro2.0/src/pages/FabricCA/models/CAUserManager.js').default) });
app.model({ namespace: 'dockerImage', ...(require('D:/work/pro2.0/src/pages/Host/models/dockerImage.js').default) });
app.model({ namespace: 'dockerList', ...(require('D:/work/pro2.0/src/pages/Host/models/dockerList.js').default) });
app.model({ namespace: 'dockerNet', ...(require('D:/work/pro2.0/src/pages/Host/models/dockerNet.js').default) });
app.model({ namespace: 'dockerVol', ...(require('D:/work/pro2.0/src/pages/Host/models/dockerVol.js').default) });
app.model({ namespace: 'host', ...(require('D:/work/pro2.0/src/pages/Host/models/host.js').default) });
app.model({ namespace: 'peerModel', ...(require('D:/work/pro2.0/src/pages/Network/models/peerModel.js').default) });
app.model({ namespace: 'geographic', ...(require('D:/work/pro2.0/src/pages/Account/Settings/models/geographic.js').default) });
app.model({ namespace: 'error', ...(require('D:/work/pro2.0/src/pages/Exception/models/error.js').default) });
