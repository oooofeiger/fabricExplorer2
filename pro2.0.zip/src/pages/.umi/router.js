import React from 'react';
import { Router as DefaultRouter, Route, Switch } from 'react-router-dom';
import dynamic from 'umi/dynamic';
import renderRoutes from 'umi/_renderRoutes';
import RendererWrapper0 from 'D:/work/pro2.0/src/pages/.umi/LocaleWrapper.jsx'

let Router = require('dva/router').routerRedux.ConnectedRouter;

let routes = [
  {
    "path": "/user",
    "component": dynamic({ loader: () => import('../../layouts/UserLayout'), loading: require('D:/work/pro2.0/src/components/PageLoading/index').default }),
    "routes": [
      {
        "path": "/user",
        "redirect": "/user/login",
        "exact": true
      },
      {
        "path": "/user/login",
        "component": dynamic({ loader: () => import('../User/Login'), loading: require('D:/work/pro2.0/src/components/PageLoading/index').default }),
        "exact": true
      },
      {
        "path": "/user/register",
        "component": dynamic({ loader: () => import('../User/Register'), loading: require('D:/work/pro2.0/src/components/PageLoading/index').default }),
        "exact": true
      },
      {
        "path": "/user/password",
        "component": dynamic({ loader: () => import('../User/Password'), loading: require('D:/work/pro2.0/src/components/PageLoading/index').default }),
        "exact": true
      },
      {
        "path": "/user/register-result",
        "component": dynamic({ loader: () => import('../User/RegisterResult'), loading: require('D:/work/pro2.0/src/components/PageLoading/index').default }),
        "exact": true
      },
      {
        "component": () => React.createElement(require('D:/work/pro2.0/node_modules/umi-build-dev/lib/plugins/404/NotFound.js').default, { pagesPath: 'src/pages', hasRoutesInConfig: true })
      }
    ]
  },
  {
    "path": "/",
    "component": dynamic({ loader: () => import('../../layouts/BasicLayout'), loading: require('D:/work/pro2.0/src/components/PageLoading/index').default }),
    "Routes": [require('../Authorized').default],
    "authority": [
      "admin",
      "non-root",
      "root"
    ],
    "routes": [
      {
        "path": "/",
        "redirect": "/fabricCA",
        "exact": true
      },
      {
        "name": "fabricCA",
        "path": "/fabricCA",
        "icon": "form",
        "routes": [
          {
            "path": "/fabricCA",
            "redirect": "/fabricCA/CAManager",
            "exact": true
          },
          {
            "path": "/fabricCA/CAManager",
            "name": "CAManager",
            "component": dynamic({ loader: () => import('../FabricCA/CAManager'), loading: require('D:/work/pro2.0/src/components/PageLoading/index').default }),
            "exact": true
          },
          {
            "path": "/fabricCA/CAUser",
            "name": "CAUserManager",
            "component": dynamic({ loader: () => import('../FabricCA/CAUser'), loading: require('D:/work/pro2.0/src/components/PageLoading/index').default }),
            "exact": true
          },
          {
            "path": "/fabricCA/UserCert",
            "name": "UserCert",
            "component": dynamic({ loader: () => import('../FabricCA/UserCert'), loading: require('D:/work/pro2.0/src/components/PageLoading/index').default }),
            "exact": true
          },
          {
            "component": () => React.createElement(require('D:/work/pro2.0/node_modules/umi-build-dev/lib/plugins/404/NotFound.js').default, { pagesPath: 'src/pages', hasRoutesInConfig: true })
          }
        ]
      },
      {
        "path": "/host",
        "name": "host",
        "icon": "form",
        "routes": [
          {
            "path": "/host",
            "redirect": "/host/manager",
            "exact": true
          },
          {
            "path": "/host/manager",
            "name": "host",
            "component": dynamic({ loader: () => import('../Host/hostManager'), loading: require('D:/work/pro2.0/src/components/PageLoading/index').default }),
            "exact": true
          },
          {
            "path": "/host/docker/list",
            "name": "dockerManager",
            "component": dynamic({ loader: () => import('../Host/dockerList'), loading: require('D:/work/pro2.0/src/components/PageLoading/index').default }),
            "exact": true
          },
          {
            "path": "/host/docker/imageManager",
            "name": "imageManager",
            "component": dynamic({ loader: () => import('../Host/dockerImage'), loading: require('D:/work/pro2.0/src/components/PageLoading/index').default }),
            "exact": true
          },
          {
            "path": "/host/docker/networkManager",
            "name": "networkManager",
            "component": dynamic({ loader: () => import('../Host/dockerNet'), loading: require('D:/work/pro2.0/src/components/PageLoading/index').default }),
            "exact": true
          },
          {
            "path": "/host/docker/volumeManager",
            "name": "volumeManager",
            "component": dynamic({ loader: () => import('../Host/dockerVolume'), loading: require('D:/work/pro2.0/src/components/PageLoading/index').default }),
            "exact": true
          },
          {
            "component": () => React.createElement(require('D:/work/pro2.0/node_modules/umi-build-dev/lib/plugins/404/NotFound.js').default, { pagesPath: 'src/pages', hasRoutesInConfig: true })
          }
        ]
      },
      {
        "path": "/network",
        "name": "network",
        "icon": "form",
        "routes": [
          {
            "path": "/network",
            "redirect": "/network/peer",
            "exact": true
          },
          {
            "path": "/network/peer",
            "name": "peer",
            "icon": "form",
            "component": dynamic({ loader: () => import('../Network/peer/peer'), loading: require('D:/work/pro2.0/src/components/PageLoading/index').default }),
            "exact": true
          },
          {
            "path": "/network/orderer",
            "name": "orderer",
            "icon": "form",
            "component": dynamic({ loader: () => import('../Network/orderer/orderer'), loading: require('D:/work/pro2.0/src/components/PageLoading/index').default }),
            "exact": true
          },
          {
            "component": () => React.createElement(require('D:/work/pro2.0/node_modules/umi-build-dev/lib/plugins/404/NotFound.js').default, { pagesPath: 'src/pages', hasRoutesInConfig: true })
          }
        ]
      },
      {
        "name": "account",
        "icon": "user",
        "path": "/account",
        "routes": [
          {
            "path": "/account/settings",
            "name": "settings",
            "component": dynamic({ loader: () => import('../Account/Settings/Info'), loading: require('D:/work/pro2.0/src/components/PageLoading/index').default }),
            "routes": [
              {
                "path": "/account/settings",
                "redirect": "/account/settings/base",
                "exact": true
              },
              {
                "path": "/account/settings/base",
                "component": dynamic({ loader: () => import('../Account/Settings/BaseView'), loading: require('D:/work/pro2.0/src/components/PageLoading/index').default }),
                "exact": true
              },
              {
                "path": "/account/settings/binding",
                "component": dynamic({ loader: () => import('../Account/Settings/BindingView'), loading: require('D:/work/pro2.0/src/components/PageLoading/index').default }),
                "exact": true
              },
              {
                "component": () => React.createElement(require('D:/work/pro2.0/node_modules/umi-build-dev/lib/plugins/404/NotFound.js').default, { pagesPath: 'src/pages', hasRoutesInConfig: true })
              }
            ]
          },
          {
            "component": () => React.createElement(require('D:/work/pro2.0/node_modules/umi-build-dev/lib/plugins/404/NotFound.js').default, { pagesPath: 'src/pages', hasRoutesInConfig: true })
          }
        ]
      },
      {
        "path": "/exception",
        "routes": [
          {
            "path": "/exception/403",
            "component": dynamic({ loader: () => import('../Exception/403'), loading: require('D:/work/pro2.0/src/components/PageLoading/index').default }),
            "exact": true
          },
          {
            "path": "/exception/404",
            "component": dynamic({ loader: () => import('../Exception/404'), loading: require('D:/work/pro2.0/src/components/PageLoading/index').default }),
            "exact": true
          },
          {
            "path": "/exception/500",
            "component": dynamic({ loader: () => import('../Exception/500'), loading: require('D:/work/pro2.0/src/components/PageLoading/index').default }),
            "exact": true
          },
          {
            "path": "/exception/trigger",
            "hideInMenu": true,
            "component": dynamic({ loader: () => import('../Exception/TriggerException'), loading: require('D:/work/pro2.0/src/components/PageLoading/index').default }),
            "exact": true
          },
          {
            "component": () => React.createElement(require('D:/work/pro2.0/node_modules/umi-build-dev/lib/plugins/404/NotFound.js').default, { pagesPath: 'src/pages', hasRoutesInConfig: true })
          }
        ]
      },
      {
        "component": dynamic({ loader: () => import('../404'), loading: require('D:/work/pro2.0/src/components/PageLoading/index').default }),
        "exact": true
      },
      {
        "component": () => React.createElement(require('D:/work/pro2.0/node_modules/umi-build-dev/lib/plugins/404/NotFound.js').default, { pagesPath: 'src/pages', hasRoutesInConfig: true })
      }
    ]
  },
  {
    "component": () => React.createElement(require('D:/work/pro2.0/node_modules/umi-build-dev/lib/plugins/404/NotFound.js').default, { pagesPath: 'src/pages', hasRoutesInConfig: true })
  }
];
window.g_plugins.applyForEach('patchRoutes', { initialValue: routes });

export default function() {
  return (
<RendererWrapper0>
          <Router history={window.g_history}>
      { renderRoutes(routes, {}) }
    </Router>
        </RendererWrapper0>
  );
}
