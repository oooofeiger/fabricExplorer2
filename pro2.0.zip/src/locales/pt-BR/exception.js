export default {
  'app.exception.back': 'Voltar para Início',
  'app.exception.description.403': 'Desculpe, você não tem acesso a esta página',
  'app.exception.description.404': 'Desculpe, a página que você visitou não existe',
  'app.exception.description.500': 'Desculpe, o servidor está reportando um erro',
};
